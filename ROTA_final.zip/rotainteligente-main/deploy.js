#!/usr/bin/env node
/**
 * ROTA — Script de Deploy Autônomo
 * Execute: node deploy.js
 * Faz tudo automaticamente após o login no Railway.
 */

const { execSync, spawnSync } = require("child_process");
const https = require("https");
const fs = require("fs");
const path = require("path");
const readline = require("readline");

// ─── CORES ────────────────────────────────────────────────────────────────────
const C = {
  reset: "\x1b[0m", green: "\x1b[32m", red: "\x1b[31m",
  yellow: "\x1b[33m", cyan: "\x1b[36m", bold: "\x1b[1m", dim: "\x1b[2m"
};
const ok  = (m) => console.log(`${C.green}  ✓ ${m}${C.reset}`);
const err = (m) => console.log(`${C.red}  ✗ ${m}${C.reset}`);
const inf = (m) => console.log(`${C.cyan}  → ${m}${C.reset}`);
const hdr = (m) => console.log(`\n${C.bold}${C.cyan}━━━ ${m} ━━━${C.reset}`);
const wrn = (m) => console.log(`${C.yellow}  ⚠ ${m}${C.reset}`);

// ─── EXECUTOR ─────────────────────────────────────────────────────────────────
function run(cmd, opts = {}) {
  try {
    const out = execSync(cmd, {
      encoding: "utf8",
      stdio: opts.silent ? "pipe" : "pipe",
      timeout: opts.timeout || 120000,
      ...opts
    });
    return { ok: true, out: out.trim() };
  } catch (e) {
    return { ok: false, out: (e.stdout || "").trim(), err: (e.stderr || e.message || "").trim() };
  }
}

function runVisible(cmd, opts = {}) {
  inf(`Executando: ${cmd}`);
  const result = spawnSync("bash", ["-c", cmd], {
    stdio: "inherit",
    timeout: opts.timeout || 180000
  });
  return result.status === 0;
}

// ─── HTTP ─────────────────────────────────────────────────────────────────────
function httpRequest(opts, body = null) {
  return new Promise((resolve) => {
    const req = https.request(opts, (res) => {
      let data = "";
      res.on("data", (c) => (data += c));
      res.on("end", () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(data) }); }
        catch { resolve({ status: res.statusCode, body: data }); }
      });
    });
    req.on("error", (e) => resolve({ status: 0, body: null, error: e.message }));
    req.setTimeout(15000, () => { req.destroy(); resolve({ status: 0, body: null, error: "timeout" }); });
    if (body) req.write(body);
    req.end();
  });
}

async function apiGet(host, path, token) {
  return httpRequest({
    hostname: host, port: 443, path,
    headers: token ? { Authorization: `Bearer ${token}` } : {}
  });
}

async function apiPost(host, path, body) {
  const b = JSON.stringify(body);
  return httpRequest({
    hostname: host, port: 443, path,
    method: "POST",
    headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(b) }
  }, b);
}

// ─── MAIN ─────────────────────────────────────────────────────────────────────
async function main() {
  console.log(`\n${C.bold}${C.cyan}`);
  console.log("╔══════════════════════════════════════════════════════╗");
  console.log("║        ROTA — Deploy Autônomo para Railway           ║");
  console.log("║        Instituto Guia Social                         ║");
  console.log("╚══════════════════════════════════════════════════════╝");
  console.log(C.reset);

  // ─── PASSO 1: Verificar Node.js ────────────────────────────────────────────
  hdr("PASSO 1 — Verificando ambiente");
  const nodeVer = process.version;
  const major = parseInt(nodeVer.slice(1));
  if (major < 18) {
    err(`Node.js ${nodeVer} muito antigo. Instale a versão 18 ou superior em nodejs.org`);
    process.exit(1);
  }
  ok(`Node.js ${nodeVer}`);

  // Verificar que está na pasta certa
  if (!fs.existsSync("server.ts") || !fs.existsSync("prisma/schema.prisma")) {
    err("Execute este script dentro da pasta do projeto ROTA (onde está o server.ts)");
    err("Navegue até a pasta: cd rotainteligente-main");
    err("Depois rode: node deploy.js");
    process.exit(1);
  }
  ok("Pasta do projeto correta");

  // ─── PASSO 2: Verificar e corrigir código ──────────────────────────────────
  hdr("PASSO 2 — Verificando e corrigindo código");

  // package.json
  const pkg = JSON.parse(fs.readFileSync("package.json", "utf8"));
  let pkgChanged = false;
  if (!pkg.scripts.start) {
    pkg.scripts.start = "NODE_ENV=production node --loader tsx/esm server.ts";
    pkgChanged = true;
    ok("Script 'start' adicionado ao package.json");
  } else {
    ok("Script 'start' já existe");
  }
  if (!pkg.scripts.postinstall) {
    pkg.scripts.postinstall = "prisma generate";
    pkgChanged = true;
  }
  if (!pkg.scripts["db:push"]) {
    pkg.scripts["db:push"] = "prisma db push";
    pkgChanged = true;
  }
  if (pkgChanged) {
    fs.writeFileSync("package.json", JSON.stringify(pkg, null, 2));
    ok("package.json atualizado");
  }

  // schema.prisma
  let schema = fs.readFileSync("prisma/schema.prisma", "utf8");
  if (schema.includes('provider = "sqlite"')) {
    schema = schema.replace('provider = "sqlite"', 'provider = "postgresql"');
    fs.writeFileSync("prisma/schema.prisma", schema);
    ok("Schema corrigido: sqlite → postgresql");
  } else {
    ok("Schema já usa postgresql");
  }

  // .gitignore
  let gitignore = fs.readFileSync(".gitignore", "utf8");
  if (!gitignore.includes("prisma/dev.db")) {
    fs.appendFileSync(".gitignore", "\nprisma/dev.db\nprisma/dev.db-journal\n");
    ok(".gitignore atualizado");
  }

  // ─── PASSO 3: Instalar Railway CLI ─────────────────────────────────────────
  hdr("PASSO 3 — Instalando Railway CLI");
  const railwayCheck = run("railway --version");
  if (!railwayCheck.ok) {
    inf("Instalando @railway/cli...");
    const installed = runVisible("npm install -g @railway/cli");
    if (!installed) {
      err("Falha ao instalar Railway CLI");
      err("Tente manualmente: npm install -g @railway/cli");
      process.exit(1);
    }
    ok("Railway CLI instalado");
  } else {
    ok(`Railway CLI ${railwayCheck.out}`);
  }

  // ─── PASSO 4: Autenticar no Railway ────────────────────────────────────────
  hdr("PASSO 4 — Autenticando no Railway");
  const whoami = run("railway whoami");
  if (whoami.ok && whoami.out && !whoami.out.includes("not logged")) {
    ok(`Já autenticado como: ${whoami.out}`);
  } else {
    console.log(`\n${C.yellow}${C.bold}`);
    console.log("  ┌──────────────────────────────────────────────────┐");
    console.log("  │  AÇÃO NECESSÁRIA — apenas uma vez                │");
    console.log("  │                                                  │");
    console.log("  │  Uma janela do browser vai abrir.                │");
    console.log("  │  Faça login com sua conta Railway.               │");
    console.log("  │  Depois volte aqui — o script continua sozinho.  │");
    console.log("  └──────────────────────────────────────────────────┘");
    console.log(C.reset + "\n");
    const loginOk = runVisible("railway login");
    if (!loginOk) {
      err("Falha no login Railway");
      process.exit(1);
    }
    const whoami2 = run("railway whoami");
    if (whoami2.ok) {
      ok(`Autenticado como: ${whoami2.out}`);
    } else {
      err("Não foi possível confirmar autenticação");
      process.exit(1);
    }
  }

  // ─── PASSO 5: Vincular ao projeto ──────────────────────────────────────────
  hdr("PASSO 5 — Vinculando ao projeto Railway");
  const status = run("railway status");
  if (status.ok && status.out.includes("rotainteligente")) {
    ok("Já vinculado ao projeto rotainteligente");
  } else {
    console.log(`\n${C.yellow}${C.bold}`);
    console.log("  ┌──────────────────────────────────────────────────┐");
    console.log("  │  AÇÃO NECESSÁRIA — apenas uma vez                │");
    console.log("  │                                                  │");
    console.log("  │  Selecione o projeto: rotainteligente            │");
    console.log("  │  Selecione o serviço: rotainteligente (app)      │");
    console.log("  │  NÃO selecione o banco PostgreSQL                │");
    console.log("  └──────────────────────────────────────────────────┘");
    console.log(C.reset + "\n");
    const linkOk = runVisible("railway link");
    if (!linkOk) {
      err("Falha ao vincular projeto");
      err("Tente: railway unlink && railway link");
      process.exit(1);
    }
    ok("Projeto vinculado");
  }

  // ─── PASSO 6: Verificar variáveis de ambiente ──────────────────────────────
  hdr("PASSO 6 — Configurando variáveis de ambiente");
  const vars = run("railway variables");
  const varsOut = vars.out || "";

  if (!varsOut.includes("DATABASE_URL")) {
    err("DATABASE_URL não encontrada nas variáveis!");
    err("Acesse railway.app → seu projeto → +New → Database → PostgreSQL");
    err("Depois rode este script novamente.");
    process.exit(1);
  }
  ok("DATABASE_URL encontrada");

  const needsJwt = !varsOut.includes("JWT_SECRET") ||
    varsOut.includes("rota-dev-secret") ||
    varsOut.includes("gere-com");

  if (needsJwt) {
    inf("Gerando JWT secrets seguros...");
    const crypto = require("crypto");
    const jwtSecret = crypto.randomBytes(32).toString("base64");
    const jwtRefresh = crypto.randomBytes(32).toString("base64");
    run(`railway variables set JWT_SECRET="${jwtSecret}"`);
    run(`railway variables set JWT_REFRESH_SECRET="${jwtRefresh}"`);
    ok("JWT_SECRET gerado e configurado");
    ok("JWT_REFRESH_SECRET gerado e configurado");
  } else {
    ok("JWT_SECRET já configurado");
  }

  if (!varsOut.includes("NODE_ENV=production")) {
    run('railway variables set NODE_ENV=production');
    ok("NODE_ENV=production configurado");
  } else {
    ok("NODE_ENV=production já configurado");
  }

  // ─── PASSO 7: Criar tabelas no banco ───────────────────────────────────────
  hdr("PASSO 7 — Criando tabelas no banco de dados");
  inf("Executando prisma db push (pode levar 30 segundos)...");

  let dbPushOk = false;
  for (let tentativa = 1; tentativa <= 3; tentativa++) {
    const dbPush = run("railway run npx prisma db push --accept-data-loss", { timeout: 180000 });
    if (dbPush.ok || (dbPush.out && (dbPush.out.includes("in sync") || dbPush.out.includes("migrations")))) {
      dbPushOk = true;
      break;
    }
    if (tentativa < 3) {
      wrn(`Tentativa ${tentativa} falhou. Aguardando 30s...`);
      await new Promise(r => setTimeout(r, 30000));
    }
  }

  if (!dbPushOk) {
    err("Não foi possível criar as tabelas.");
    err("Verifique se o banco PostgreSQL está ativo no Railway.");
    err("Acesse railway.app → projeto → verifique se PostgreSQL está verde.");
    process.exit(1);
  }
  ok("Tabelas criadas com sucesso");

  // ─── PASSO 8: Executar seed ────────────────────────────────────────────────
  hdr("PASSO 8 — Criando usuário admin e dados iniciais");
  const seedScript = `
const {PrismaClient} = require('@prisma/client');
const bcrypt = require('bcryptjs');
const p = new PrismaClient();
async function seed() {
  const hash = await bcrypt.hash('admin123', 12);
  const admin = await p.user.upsert({
    where:{email:'admin@guiasocial.org'},
    update:{},
    create:{
      email:'admin@guiasocial.org',
      password:hash,
      name:'Administrador ROTA',
      role:'SUPER_ADMIN'
    }
  });
  const count = await p.project.count();
  if(count===0){
    const proj = await p.project.create({
      data:{
        nome:'Guia Digital Teen 2026',
        edital:'FMCA/COMDICA',
        financiador:'Fundo Municipal da Criança',
        area:'Digital',
        valor:320000,
        status:'Inscrito',
        prazo:new Date('2026-04-15'),
        responsavelId:admin.id,
        probabilidade:72,
        risco:'Médio',
        aderencia:5,
        territorio:'RPA 6 — Pina / Ipsep',
        publico:'Adolescentes 12–18 anos',
        competitividade:'Alta',
        proximoPasso:'Aguardar resultado do edital',
        ptScore:8.1,
        observacao:'Alto alinhamento com COMDICA.',
        ano:2026,
        categoriaEdital:'Fundo Municipal',
        programaInterno:'Inclusão Digital',
        scoreCompliance:92,
        scoreRiscoGlosa:8,
        ptCriterios:[
          {critério:'Aderência',score:9},
          {critério:'Força Conceitual',score:8},
          {critério:'Cap. Institucional',score:8},
          {critério:'Maturidade',score:7}
        ],
        historico:[
          {data:'10/02/2026',acao:'Oportunidade identificada',autor:'Janaina Constantino'},
          {data:'14/02/2026',acao:'Triagem aprovada',autor:'Viviane Castro'},
          {data:'12/03/2026',acao:'Submetido',autor:'Viviane Castro'}
        ]
      }
    });
    await p.alert.create({
      data:{
        projectId:proj.id,
        titulo:'Documento a Vencer',
        mensagem:'CND Municipal Recife vence em 15 dias.',
        nivel:'N4',
        status:'PENDENTE',
        tipo:'DOCUMENTO',
        prazo:new Date(Date.now()+15*24*60*60*1000)
      }
    });
    console.log('PROJETO:OK');
  } else {
    console.log('PROJETO:JA_EXISTE');
  }
  console.log('ADMIN:OK:'+admin.email+':'+admin.role);
  await p.$disconnect();
}
seed().catch(e=>{console.error('SEED_ERRO:'+e.message);process.exit(1);});
`.trim();

  const tmpSeed = path.join(require("os").tmpdir(), "rota_seed.js");
  fs.writeFileSync(tmpSeed, seedScript);

  const seedResult = run(`railway run node ${tmpSeed}`, { timeout: 120000 });
  if (seedResult.out.includes("ADMIN:OK")) {
    ok("Usuário admin criado/confirmado");
    if (seedResult.out.includes("PROJETO:OK")) ok("Projeto inicial criado");
    if (seedResult.out.includes("PROJETO:JA_EXISTE")) ok("Projeto já existia");
  } else {
    wrn("Seed com aviso: " + (seedResult.err || seedResult.out).substring(0, 100));
  }
  fs.unlinkSync(tmpSeed);

  // ─── PASSO 9: Redeploy ─────────────────────────────────────────────────────
  hdr("PASSO 9 — Executando redeploy");
  inf("Acionando redeploy no Railway...");
  const redeploy = run("railway redeploy --yes", { timeout: 30000 });
  if (redeploy.ok) {
    ok("Redeploy acionado");
  } else {
    wrn("Comando redeploy retornou aviso (normal). Deploy pode já estar em progresso.");
  }

  // Aguardar servidor subir
  inf("Aguardando servidor iniciar (60 segundos)...");
  await new Promise(r => setTimeout(r, 60000));

  // ─── PASSO 10: Detectar URL ─────────────────────────────────────────────────
  hdr("PASSO 10 — Obtendo URL do sistema");
  let appUrl = "";
  const domainResult = run("railway domain");
  if (domainResult.ok && domainResult.out.includes(".")) {
    appUrl = domainResult.out.trim().replace(/^https?:\/\//, "");
    ok(`URL: https://${appUrl}`);
  } else {
    // Tentar extrair do status
    const statusResult = run("railway status");
    const match = (statusResult.out || "").match(/https?:\/\/([^\s]+)/);
    if (match) {
      appUrl = match[1].replace(/\/$/, "");
      ok(`URL: https://${appUrl}`);
    } else {
      wrn("URL não detectada automaticamente.");
      wrn("Acesse railway.app → serviço → Settings → Domains → Generate Domain");
      wrn("Depois rode: node deploy.js --validate-only https://sua-url.railway.app");
      appUrl = "rotainteligente-production.up.railway.app";
    }
  }

  // ─── PASSO 11: Validar endpoints ───────────────────────────────────────────
  hdr("PASSO 11 — Validando sistema");
  inf("Testando endpoints (aguarde)...");

  // Retry com backoff para dar tempo ao servidor
  let token = null;
  let healthOk = false;
  for (let i = 0; i < 6; i++) {
    const health = await apiGet(appUrl, "/api/health");
    if (health.status === 200 && health.body && health.body.status === "ok") {
      healthOk = true;
      ok("Health check: OK");
      break;
    }
    if (i < 5) {
      inf(`Servidor ainda iniciando... (tentativa ${i+1}/6, aguardando 20s)`);
      await new Promise(r => setTimeout(r, 20000));
    }
  }

  if (!healthOk) {
    wrn("Health check não respondeu. O servidor pode estar demorando mais.");
    wrn("Acesse os logs: railway logs --tail 30");
  }

  // Login
  const loginResp = await apiPost(appUrl, "/api/auth/login", {
    email: "admin@guiasocial.org",
    password: "admin123"
  });

  if (loginResp.status === 200 && loginResp.body && loginResp.body.accessToken) {
    token = loginResp.body.accessToken;
    ok(`Login: OK — ${loginResp.body.user.name} (${loginResp.body.user.role})`);
  } else {
    wrn(`Login com admin123: status ${loginResp.status}`);
    wrn("Isso pode ser normal se a senha já foi trocada anteriormente.");
  }

  if (token) {
    const proj = await apiGet(appUrl, "/api/projects", token);
    if (proj.status === 200 && Array.isArray(proj.body)) {
      ok(`Projetos: ${proj.body.length} no banco`);
    } else {
      err(`Projetos: falhou (${proj.status})`);
    }

    const alerts = await apiGet(appUrl, "/api/alerts", token);
    if (alerts.status === 200 && Array.isArray(alerts.body)) {
      const comPrazo = alerts.body.filter(a => a.prazo).length;
      ok(`Alertas: ${alerts.body.length} total, ${comPrazo} com prazo`);
    }

    const stats = await apiGet(appUrl, "/api/stats", token);
    if (stats.status === 200) {
      ok(`Stats: ${stats.body.totalProjects} projetos, taxa ${(stats.body.approvalRate||0).toFixed(0)}%`);
    }
  }

  // ─── PASSO 12: Trocar senha ─────────────────────────────────────────────────
  hdr("PASSO 12 — Trocando senha padrão (segurança)");
  const crypto = require("crypto");
  const base = crypto.randomBytes(14).toString("base64").replace(/[+/=]/g, "").substring(0, 14);
  const novaSenha = "Rota@" + base + "26";

  const changeScript = `
const {PrismaClient} = require('@prisma/client');
const bcrypt = require('bcryptjs');
const p = new PrismaClient();
async function change() {
  const hash = await bcrypt.hash('${novaSenha}', 12);
  await p.user.update({
    where:{email:'admin@guiasocial.org'},
    data:{password:hash}
  });
  console.log('SENHA_TROCADA_OK');
  await p.$disconnect();
}
change().catch(e=>{console.error('ERRO:'+e.message);process.exit(1);});
`.trim();

  const tmpChange = path.join(require("os").tmpdir(), "rota_change.js");
  fs.writeFileSync(tmpChange, changeScript);
  const changeResult = run(`railway run node ${tmpChange}`, { timeout: 60000 });
  fs.unlinkSync(tmpChange);

  if (changeResult.out.includes("SENHA_TROCADA_OK")) {
    ok("Senha trocada com sucesso");
  } else {
    wrn("Não foi possível confirmar a troca de senha via script");
  }

  // Salvar credenciais em arquivo local
  const credsFile = path.join(process.cwd(), "CREDENCIAIS_ROTA.txt");
  const credsContent = [
    "╔══════════════════════════════════════════════════════╗",
    "║         ROTA — CREDENCIAIS DE ACESSO                 ║",
    "╠══════════════════════════════════════════════════════╣",
    `║  URL    : https://${appUrl.padEnd(33)}║`,
    `║  Email  : admin@guiasocial.org                       ║`,
    `║  Senha  : ${novaSenha.padEnd(43)}║`,
    "╠══════════════════════════════════════════════════════╣",
    `║  Gerado em: ${new Date().toLocaleString("pt-BR").padEnd(40)}║`,
    "║  GUARDE ESTE ARQUIVO EM LOCAL SEGURO                 ║",
    "║  Depois delete-o deste computador                    ║",
    "╚══════════════════════════════════════════════════════╝",
    "",
    "Telas disponíveis após login:",
    "  Dashboard, Pipeline, Editais, Alertas,",
    "  Documentos, Memória, Relatórios",
  ].join("\n");

  fs.writeFileSync(credsFile, credsContent);

  // ─── RELATÓRIO FINAL ────────────────────────────────────────────────────────
  console.log(`\n${C.bold}${C.green}`);
  console.log("╔══════════════════════════════════════════════════════╗");
  console.log("║        ROTA — DEPLOY CONCLUÍDO COM SUCESSO           ║");
  console.log("╠══════════════════════════════════════════════════════╣");
  console.log(`║  URL   : https://${appUrl.substring(0, 35).padEnd(35)}║`);
  console.log("║  Email : admin@guiasocial.org                        ║");
  console.log(`║  Senha : ${novaSenha.padEnd(43)}║`);
  console.log("╠══════════════════════════════════════════════════════╣");
  console.log("║  ✓ Banco de dados criado e populado                  ║");
  console.log("║  ✓ Usuário admin configurado                         ║");
  console.log("║  ✓ Senha padrão trocada                              ║");
  console.log("║  ✓ Sistema acessível via HTTPS                       ║");
  console.log("╠══════════════════════════════════════════════════════╣");
  console.log("║  Arquivo com credenciais salvo em:                   ║");
  console.log("║  CREDENCIAIS_ROTA.txt (nesta pasta)                  ║");
  console.log("╚══════════════════════════════════════════════════════╝");
  console.log(C.reset);

  console.log(`${C.yellow}  ⚠ IMPORTANTE: guarde a senha acima antes de fechar esta janela.${C.reset}`);
  console.log(`${C.yellow}  ⚠ Ela também foi salva em CREDENCIAIS_ROTA.txt nesta pasta.${C.reset}\n`);
}

// ─── MODO VALIDATE-ONLY ───────────────────────────────────────────────────────
async function validateOnly(url) {
  const host = url.replace(/^https?:\/\//, "").replace(/\/$/, "");
  hdr(`Validando ${host}`);

  const health = await apiGet(host, "/api/health");
  health.status === 200 ? ok("Health: OK") : err(`Health: ${health.status}`);

  const login = await apiPost(host, "/api/auth/login", {
    email: "admin@guiasocial.org", password: "admin123"
  });

  if (login.status === 200 && login.body.accessToken) {
    ok(`Login: OK — ${login.body.user.role}`);
    const token = login.body.accessToken;
    const proj = await apiGet(host, "/api/projects", token);
    proj.status === 200 ? ok(`Projetos: ${proj.body.length}`) : err(`Projetos: ${proj.status}`);
  } else {
    wrn(`Login: ${login.status} — senha pode já ter sido trocada`);
  }
}

// ─── ENTRY POINT ──────────────────────────────────────────────────────────────
const args = process.argv.slice(2);
if (args[0] === "--validate-only" && args[1]) {
  validateOnly(args[1]).catch(console.error);
} else {
  main().catch((e) => {
    console.error(`\n${C.red}Erro fatal: ${e.message}${C.reset}`);
    console.error("Execute novamente: node deploy.js");
    process.exit(1);
  });
}
