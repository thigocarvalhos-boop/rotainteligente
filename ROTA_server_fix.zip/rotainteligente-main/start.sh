#!/bin/sh
# ROTA — Script de inicialização para produção
# Railway executa este script como start command

echo "→ Verificando banco de dados..."
npx prisma db push --accept-data-loss 2>&1 && echo "✓ Banco sincronizado" || echo "⚠ db push com aviso (pode já estar sincronizado)"

echo "→ Iniciando servidor ROTA..."
exec node --loader tsx/esm server.ts
